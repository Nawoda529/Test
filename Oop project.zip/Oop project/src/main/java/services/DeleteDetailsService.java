package services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import controller.DBConnect;

public class DeleteDetailsService {

    public static void deleteUser(String id) {
        Connection con = null;
        PreparedStatement stmt = null;
        try {
            con = DBConnect.getConnection();
            String sql = "DELETE FROM details WHERE id = ?";
            stmt = con.prepareStatement(sql);
            stmt.setString(1, id);
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
