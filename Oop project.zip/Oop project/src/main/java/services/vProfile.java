package services;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import controller.DBConnect;
import model.customer;

public class vProfile {
    public static List<customer> getCustomerDetails(String Email , String Password) throws ClassNotFoundException, SQLException {
        ArrayList<customer> cus = new ArrayList<>();
        Statement statement = DBConnect.getConnection().createStatement();

        try {
        	String sql ="select * from details where email = '"+Email+"' and password = '"+Password+"' ORDER BY id";

            ResultSet rs = statement.executeQuery(sql);

            while(rs.next()) {
                
                
                customer user = new customer();
                user.setId(rs.getString("id"));
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setAddress(rs.getString("address"));
                user.setNumber(rs.getString("number"));
                cus.add(user);
            }

        } catch(Exception e) {
            e.printStackTrace();
        }

        return cus;
    }
}
