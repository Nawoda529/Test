package services;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import controller.DBConnect;
import model.childCus;
import model.customer;

public class vProChild {
    public static ArrayList<childCus> getCustomerDetails(String Email , String Password) throws ClassNotFoundException, SQLException {
        ArrayList<childCus> cCus = new ArrayList<>();
        Statement statement = DBConnect.getConnection().createStatement();

        try {
        	String sql ="select * from schoolchild where email = '"+Email+"' and password = '"+Password+"' ORDER BY id";

            ResultSet rs = statement.executeQuery(sql);

            while(rs.next()) {
                
                
            	childCus user = new childCus();
                user.setId(rs.getString("id"));
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                user.setAddress(rs.getString("address"));
                user.setGrade(rs.getString("grade"));
                cCus.add(user);
            }

        } catch(Exception e) {
            e.printStackTrace();
        }

        return cCus;
    }

}
