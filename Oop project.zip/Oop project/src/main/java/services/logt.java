package services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import controller.DBConnect;
import model.customer;

public class logt {
    // Method to retrieve a user by email and password
    public customer getUserByEmailAndPassword(String Email, String Password) {
        customer user = null;
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        try {
            connection = DBConnect.getConnection();
            String query = "SELECT * FROM details WHERE email=? AND password=?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, Email);
            preparedStatement.setString(2, Password);
            rs = preparedStatement.executeQuery();
            if (rs.next()) {
                //user = new customer();
            	 String id = rs.getString(1);
	              String name = rs.getString(2);
	              String email = rs.getString(3);
	                String address = rs.getString(4);
	                String password = rs.getString(5);
	                String number = rs.getString(6);
	                
               // user.setId(resultSet.getString("id"));
               // user.setName(resultSet.getString("name"));
                //user.setEmail(resultSet.getString("email"));
               // user.setAddress(resultSet.getString("address"));
              //  user.setPassword(resultSet.getString("password"));
              //  user.setNumber(resultSet.getString("number"));
                
                user = new customer(id , name , email , address , password , number);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return user;
    }
}
