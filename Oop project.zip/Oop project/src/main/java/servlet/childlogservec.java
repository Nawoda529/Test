package servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.childCus;
import services.logc;
import java.io.IOException;

public class childlogservec extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public childlogservec() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        logc userDAO = new logc();
        childCus user = userDAO.getUserByEmailAndPassword(email, password);

        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("email", email); // Store user's email in session for future use
            RequestDispatcher dis = request.getRequestDispatcher("Dashboard.jsp");
            dis.forward(request, response);
        } else {
            // If user is not valid, redirect back to login page
            response.sendRedirect("logingC.jsp?error=invalid");
        }
    }
}
