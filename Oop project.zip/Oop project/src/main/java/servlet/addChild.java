package servlet;


import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import services.childService;

import java.io.IOException;


public class addChild extends HttpServlet {
	private static final long serialVersionUID = 1L;
	       
	    
	    public addChild() {
	        super();
	        
	    }


		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			
			String id = request.getParameter("id");
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String address = request.getParameter("address");
			String password = request.getParameter("password");
			String grade = request.getParameter("grade");
			
			boolean isTru ;
			
			childService serv = new childService();
			isTru = serv.regChild(id, name, address, email, password, grade);
			
			if (isTru == true) {
				RequestDispatcher dis1 = request.getRequestDispatcher("successReg.jsp");
				dis1.forward(request , response);
			}
			
		
		}

}



