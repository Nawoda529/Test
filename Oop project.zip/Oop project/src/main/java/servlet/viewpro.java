package servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.customer;
import services.vProfile;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class viewpro extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try {
            List<customer> cs = vProfile.getCustomerDetails(email, password);
            request.setAttribute("customer", cs);

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        RequestDispatcher dis = request.getRequestDispatcher("Tprofile.jsp");
        dis.forward(request, response);
    }
}
