package servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import services.customerService;

import java.io.IOException;


public class addCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public addCustomer() {
        super();
        
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		String password = request.getParameter("password");
		String number = request.getParameter("number");
		
		boolean isTrue ;
		
		customerService service = new customerService();
		isTrue = customerService.regCustomer(id, name, address, email, number, password);
		
		if (isTrue == true) {
			RequestDispatcher dis = request.getRequestDispatcher("successReg.jsp");
			dis.forward(request , response);
		}
		
	
	}

}
